import React from 'react'

function About() {
  return (
     <div className="p-6 text-center text-xl">We sell awesome products!</div>
  )
}

export default About
